var DeadZone = function(x,y){
	this.setup();
}