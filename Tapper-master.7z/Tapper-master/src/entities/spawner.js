var Spawner = function(barra, numCLientes, frecuencia, retardo) {
  this.barra = barra;
  this.numCLientes = numCLientes;
  this.frecuencia = 0;
  this.retardo = retardo;

  this.step = function(dt){
    this.retardo -= dt;

    if (this.retardo < 0 && this.numCLientes > 0){
      this.frecuencia -=dt;
      if(this.frecuencia < 0 && this.numCLientes > 0) {
        console.log("Cliente va en la barra" + this.barra.y);
        this.board.add(new Client(0, this.barra.y - 10));
        this.frecuencia = frecuencia;
        this.numCLientes--;
      }
    }
  };

  this.draw = function(){};
};



